package customers;

public interface ILogger {
    void log (String logstring);
}
