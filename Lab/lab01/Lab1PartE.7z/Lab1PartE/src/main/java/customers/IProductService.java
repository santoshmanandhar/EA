package customers;

public interface IProductService {
    void addProduct(int id, String name, String category);
}
